'use client'

import { useEffect, useMemo, useState } from 'react'
import {
  Activity, BarChart3, Bell, BrainCircuit, Building2, Check, Clock3, Eye, FlaskConical,
  Gauge, LayoutDashboard, LogOut, Menu, Moon, Plus, Search, Settings, ShieldCheck,
  Sparkles, Sun, Target, Users, X, Zap,
} from 'lucide-react'

type Role = 'admin' | 'merchant'
type Feature = { label: string; icon: typeof LayoutDashboard; description: string; metrics: [string, string, string, string]; kind: string }

const merchantFeatures: Feature[] = [
  { label: 'Overview', icon: LayoutDashboard, description: "A live view of revenue, offer performance, and today's capacity.", metrics: ['₹84,620', '28.4%', '₹18,420', '₹6,280'], kind: 'overview' },
  { label: 'Campaigns', icon: Target, description: 'Create, pause, and monitor campaigns running across your business.', metrics: ['3 active', '12.8k reached', '₹42,100 revenue', '18.6% lift'], kind: 'campaigns' },
  { label: 'Offer Rules', icon: ShieldCheck, description: 'Control discount ceilings, eligibility, and approval guardrails.', metrics: ['6 rules', '20% max', '3 segments', '0 breaches'], kind: 'rules' },
  { label: 'Inventory / Capacity', icon: Building2, description: 'Protect margins by matching offers to available capacity.', metrics: ['74% filled', '26 seats left', '₹2,840 protected', '4 windows'], kind: 'inventory' },
  { label: 'Offer Inbox', icon: Bell, description: 'Review recommendations from the MomentIQ decision engine.', metrics: ['8 pending', '4 approved', '2 rejected', '₹9,240 value'], kind: 'inbox' },
  { label: 'Analytics', icon: BarChart3, description: 'Understand which offers convert, when they work, and why.', metrics: ['+18.6% lift', '31.2% CVR', '₹14.80 ROI', '642 orders'], kind: 'analytics' },
  { label: 'Business Settings', icon: Settings, description: 'Manage business profile, operating hours, and approval access.', metrics: ['Bengaluru', '3 locations', '5 members', 'Healthy'], kind: 'settings' },
]

const adminFeatures: Feature[] = [
  { label: 'Platform Overview', icon: LayoutDashboard, description: 'Monitor the decision platform across customers, merchants, and offers.', metrics: ['12,480', '94.2%', '₹2.4M', '98.7%'], kind: 'platform' },
  { label: 'Customer Explorer', icon: Users, description: 'Inspect customer signals, segments, and recent offer responses.', metrics: ['48,290 profiles', '82% signal coverage', '1,284 active', '93.1% consent'], kind: 'customers' },
  { label: 'Customer Signal Processing', icon: Activity, description: 'Validate the signals feeding decisions and identify processing gaps.', metrics: ['98.7% processed', '42k events/hr', '0.4% delayed', 'Healthy'], kind: 'signals' },
  { label: 'Merchant Management', icon: Building2, description: 'Review merchant health, integrations, and offer participation.', metrics: ['128 merchants', '116 healthy', '7 attention', '5 onboarding'], kind: 'merchants' },
  { label: 'Merchant & Offer Matching', icon: Zap, description: 'Find the best merchant, offer, and audience combinations.', metrics: ['86.4% precision', '2,840 matches', '14 segments', '12ms latency'], kind: 'matching' },
  { label: 'Offer Intelligence', icon: BrainCircuit, description: 'Run a transparent SEND, WAIT, or SKIP decision for a customer moment.', metrics: ['SEND 62%', 'WAIT 24%', 'SKIP 14%', '91.8% confidence'], kind: 'intelligence' },
  { label: 'Discount Optimizer', icon: Gauge, description: 'Evaluate permitted discount options against conversion and margin.', metrics: ['Best: 15%', '+8.4% CVR', '₹42 margin', '3 options'], kind: 'optimizer' },
  { label: 'Smart Timing', icon: Clock3, description: 'Compare send windows and choose the highest-intent moment.', metrics: ['12:30 PM best', '+21% response', '4 windows', '89% confidence'], kind: 'timing' },
  { label: 'Decision Explainability', icon: Eye, description: 'See the evidence and weights behind each recommendation.', metrics: ['6 signals', 'Transparent', '0 overrides', 'Audit ready'], kind: 'explainability' },
  { label: 'Live Offer Studio', icon: Sparkles, description: 'Compose a simulated offer and preview how it will appear.', metrics: ['4 templates', '3 channels', 'A/B ready', 'Guardrails on'], kind: 'studio' },
  { label: 'Offer Validation & Guardrails', icon: ShieldCheck, description: 'Check eligibility, discount limits, and policy compliance before send.', metrics: ['24 checks', '100% pass', '0 violations', 'Live'], kind: 'validation' },
  { label: 'Customer Offer Simulator', icon: Eye, description: 'Simulate a customer context and inspect the resulting recommendation.', metrics: ['Context ready', '3 candidates', '15% suggested', 'SEND'], kind: 'simulator' },
  { label: 'Response Simulator Integration', icon: Activity, description: 'Model likely customer responses using the available demo response engine.', metrics: ['12k runs', '68% accept', '21% ignore', '11% reject'], kind: 'responses' },
  { label: 'Seven-Day Strategy Arena', icon: FlaskConical, description: 'Compare strategies over a seven-day simulated horizon.', metrics: ['+14.2% profit', '7 days', '1,240 offers', 'Strategy A'], kind: 'arena' },
  { label: 'Baseline Strategy Comparison', icon: BarChart3, description: 'Compare the intelligent policy with a fixed-discount baseline.', metrics: ['+18.6% lift', '−12% waste', '₹42k gain', '7 days'], kind: 'baseline' },
  { label: 'Profit Analytics', icon: BarChart3, description: 'Track incremental profit, discount cost, and decision efficiency.', metrics: ['₹2.4M profit', '14.8x ROI', '₹162k cost', '+18.6%'], kind: 'profit' },
  { label: 'What-If Lab', icon: FlaskConical, description: 'Change assumptions and recalculate projected outcomes immediately.', metrics: ['15% discount', '72% fill rate', '₹84k profit', '+9.2% lift'], kind: 'whatif' },
  { label: 'Decision Timeline', icon: Clock3, description: 'Trace decisions, changes, and outcomes across the platform.', metrics: ['2,840 decisions', '99.1% logged', '6.4m events', 'Live'], kind: 'timeline' },
  { label: 'Audit & Guardrails', icon: ShieldCheck, description: 'Review policy events, overrides, and model safety checks.', metrics: ['0 critical', '12 reviews', '100% logged', 'Protected'], kind: 'audit' },
  { label: 'Model Evaluation & Tuning', icon: Gauge, description: 'Evaluate decision quality and tune thresholds using demo data.', metrics: ['91.8% accuracy', '0.86 F1', '−3.2% bias', 'Stable'], kind: 'models' },
  { label: 'Data Quality', icon: Gauge, description: 'Inspect freshness, completeness, and validity of platform data.', metrics: ['98.4% complete', '99.7% fresh', '3 warnings', 'Good'], kind: 'quality' },
  { label: 'Platform Settings & Access Control', icon: Settings, description: 'Configure evaluator access, policies, and platform defaults.', metrics: ['4 roles', '18 members', 'MFA on', 'Protected'], kind: 'admin-settings' },
]

function Logo() { return <div className="flex items-center gap-3"><div className="brand-mark"><span /></div><div className="text-[15px] font-semibold">Moment<span className="text-lime">IQ</span><div className="text-[9px] uppercase tracking-widest text-muted-foreground">Commerce intelligence</div></div></div> }
function Login({ onEnter }: { onEnter: (role: Role) => void }) { const [role, setRole] = useState<Role>('admin'); return <div className="login-shell"><div className="login-brand"><Logo /></div><div className="login-grid"><section className="login-copy"><span className="demo-badge">SIMULATED DATA</span><h1>Make every offer<br /><span className="text-lime">matter.</span></h1><p>MomentIQ turns commerce signals into profitable, timely customer moments.</p></section><section className="login-card"><h2>Welcome back</h2><p>Choose a workspace to continue.</p><div className="role-toggle"><button className={role === 'admin' ? 'active' : ''} onClick={() => setRole('admin')}>Platform Admin / Evaluator</button><button className={role === 'merchant' ? 'active' : ''} onClick={() => setRole('merchant')}>Merchant</button></div><label className="login-field">Email<input placeholder="you@company.com" /></label><label className="login-field">Password<input type="password" placeholder="Demo password" /></label><button className="button-primary mt-5 w-full" onClick={() => onEnter(role)}>Enter workspace</button></section></div></div> }

function FeatureWorkspace({ feature, role }: { feature: Feature; role: Role }) {
  const [query, setQuery] = useState(''); const [discount, setDiscount] = useState(15); const [capacity, setCapacity] = useState(72); const [status, setStatus] = useState(''); const [showForm, setShowForm] = useState(false)
  const [decision, setDecision] = useState('SEND')
  const calculatedProfit = useMemo(() => Math.round(58000 + discount * 900 + capacity * 240), [discount, capacity])
  const rowsByKind: Record<string, string[]> = {
    customers: ['Priya Sharma · High intent · 4 offers', 'Arjun Kumar · Returning · 2 offers', 'Meera Rao · At risk · 6 offers', 'Kabir Singh · New · 1 offer'],
    signals: ['Cart abandoned · processed · 12:41', 'Rain forecast · processed · 12:38', 'App opened · delayed · 12:35', 'Repeat purchase · processed · 12:31'],
    merchants: ['Brew & Bean · healthy · 3 locations', 'The Green Table · attention · 1 location', 'Urban Tiffin · onboarding · 2 locations', 'Coastal Kitchen · healthy · 5 locations'],
    matching: ['Priya × Brew & Bean × Lunch Saver · 94%', 'Arjun × Urban Tiffin × Returner · 88%', 'Meera × Green Table × Winback · 81%'],
    inbox: ['Lunch Saver · SEND · ₹240 value', 'Rainy Day Regulars · WAIT · ₹180 value', 'New Neighbour · SEND · ₹120 value'],
    campaigns: ['Lunch Saver · Active · 4,820 reached', 'Rainy Day Regulars · Active · 3,210 reached', 'New Neighbour Welcome · Draft · not launched'],
    inventory: ['Lunch seating · 74% filled · 26 seats', 'Dinner seating · 91% filled · 8 seats', 'Weekend brunch · 42% filled · 58 seats'],
    analytics: ['Lunch Saver · 31.2% CVR · ₹14.80 ROI', 'Rainy Day · 24.8% CVR · ₹11.20 ROI', 'Welcome · 18.4% CVR · ₹8.60 ROI'],
    timeline: ['12:41 · SEND decision · Priya Sharma', '12:38 · WAIT decision · Arjun Kumar', '12:35 · rule updated · discount cap'],
    audit: ['Policy check · passed · discount_cap', 'Manual review · open · campaign_284', 'Model override · none · last 24h'],
    quality: ['Offer events · 99.7% fresh · good', 'Customer consent · 93.1% complete · good', 'Merchant hours · 3 warnings · review'],
  }
  const baseRows = rowsByKind[feature.kind] ?? ['Recommendation engine · healthy · simulated', 'Policy evaluation · passed · simulated', 'Latest activity · just now · demo data']
  const rows = baseRows.filter(row => row.toLowerCase().includes(query.toLowerCase()))
  const isTable = ['customers', 'signals', 'merchants', 'matching', 'inbox', 'campaigns', 'inventory', 'analytics', 'timeline', 'audit', 'quality'].includes(feature.kind)
  const save = () => { setStatus(feature.kind === 'inbox' ? 'Offer marked approved in the simulated queue.' : feature.kind === 'campaigns' ? 'Campaign saved to the simulated campaign list.' : 'Changes saved in this simulated workspace.'); setShowForm(false) }
  const renderSpecial = () => {
    if (feature.kind === 'intelligence') return <div className="decision-grid"><div className="decision-score">{decision}<small>demo recommendation</small></div><div className="decision-panel"><strong>Decision evidence</strong><p>High lunchtime intent and 72% capacity combine with a compliant 15% discount.</p><div className="decision-actions">{['SEND', 'WAIT', 'SKIP'].map(item => <button key={item} className={decision === item ? 'button-primary' : 'button-secondary'} onClick={() => setDecision(item)}>{item}</button>)}</div></div></div>
    if (feature.kind === 'optimizer' || feature.kind === 'timing' || feature.kind === 'whatif') return <div className="control-grid"><label className="field-label">Discount / fill assumption: {discount}%<input type="range" min="0" max="30" value={discount} onChange={e => setDiscount(Number(e.target.value))} /></label><label className="field-label">Capacity assumption: {capacity}%<input type="range" min="20" max="100" value={capacity} onChange={e => setCapacity(Number(e.target.value))} /></label><div className="stat-tile"><span>Projected profit</span><strong>₹{calculatedProfit.toLocaleString('en-IN')}</strong><small>Calculated from simulated assumptions.</small></div></div>
    if (feature.kind === 'studio' || feature.kind === 'simulator') return <div className="studio-grid"><div className="stat-tile"><span>Offer preview</span><strong>{feature.kind === 'studio' ? '15% off your next lunch' : 'Best next action: SEND'}</strong><small>Preview only. No messages are sent.</small></div><div className="stat-tile"><span>Validation</span><strong className="text-lime-dark">Ready</strong><small>Eligibility and guardrails passed.</small></div></div>
    if (feature.kind === 'responses' || feature.kind === 'arena' || feature.kind === 'baseline' || feature.kind === 'models' || feature.kind === 'profit') return <div className="chart-panel"><div className="chart-bars"><span style={{ height: '45%' }} /><span style={{ height: '65%' }} /><span style={{ height: '52%' }} /><span style={{ height: '82%' }} /><span style={{ height: '70%' }} /><span style={{ height: '94%' }} /></div><div><strong>Simulated comparison</strong><p>Results are illustrative demo calculations, not production model output.</p></div></div>
    if (feature.kind === 'explainability' || feature.kind === 'validation' || feature.kind === 'rules' || feature.kind === 'admin-settings' || feature.kind === 'settings') return <div className="check-list">{['Eligibility and consent', 'Discount policy limit', 'Capacity availability', 'Audit logging'].map(item => <div key={item}><Check /><span>{item}</span><strong>Passed</strong></div>)}</div>
    return null
  }
  return <div className="flex flex-col gap-5"><div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">{feature.metrics.map((metric, index) => <div className="metric-card" key={metric}><div className="metric-icon"><feature.icon /></div><div className="mt-5 text-xs text-muted-foreground">{['Primary signal', 'Performance', 'Value', 'Status'][index]}</div><div className="mt-1 text-2xl font-semibold">{metric}</div></div>)}</div>{renderSpecial()}<section className="panel p-5"><div className="flex flex-wrap items-center justify-between gap-3"><div><h2 className="font-semibold">{feature.kind === 'inbox' ? 'Offer review queue' : feature.kind === 'customers' ? 'Customer profiles' : feature.kind === 'merchants' ? 'Merchant directory' : feature.kind === 'signals' ? 'Signal stream' : feature.label}</h2><p className="mt-1 text-xs text-muted-foreground">{role === 'merchant' ? 'Merchant demo data with local state.' : 'Evaluator demo data with transparent simulated calculations.'}</p></div><button className="button-primary" onClick={() => setShowForm(!showForm)}>{showForm ? <X /> : <Plus />} {showForm ? 'Close' : feature.kind === 'campaigns' ? 'Create campaign' : 'Run action'}</button></div>{isTable && <label className="search-box mt-5"><Search /><input value={query} onChange={e => setQuery(e.target.value)} placeholder={`Search ${feature.kind}`} /></label>}{showForm && <div className="form-box mt-5"><label className="field-label">Name<input placeholder={`New ${feature.label.toLowerCase()} item`} /></label><button className="button-light" onClick={save}><Check /> Save simulated change</button></div>}{isTable && <div className="data-list mt-5">{rows.length ? rows.map(row => <div className="data-row" key={row}><div><strong>{row.split(' · ')[0]}</strong><span>{row.split(' · ').slice(1).join(' · ')}</span></div><button className="button-ghost" onClick={() => setStatus(`Opened details for ${row.split(' · ')[0]}.`)}>View details</button></div>) : <div className="empty-workspace"><Search /><p>No matching demo records.</p></div>}</div>}{status && <div className="success-note mt-4"><Check />{status}</div>}</section></div>
}

function Page() {
  const [role, setRole] = useState<Role | null>(null); const [selected, setSelected] = useState('Platform Overview'); const [dark, setDark] = useState(true); const [menuOpen, setMenuOpen] = useState(false)
  const features = role === 'merchant' ? merchantFeatures : adminFeatures
  const allFeatures = [...merchantFeatures, ...adminFeatures]
  useEffect(() => { const sync = () => { const route = new URLSearchParams(window.location.search).get('feature'); const match = allFeatures.find(f => f.label === route); if (match) { setSelected(match.label); setRole(merchantFeatures.some(f => f.label === match.label) ? 'merchant' : 'admin') } }; sync(); window.addEventListener('popstate', sync); return () => window.removeEventListener('popstate', sync) }, [])
  const open = (feature: Feature) => { setSelected(feature.label); window.history.pushState({}, '', `?feature=${encodeURIComponent(feature.label)}`); setMenuOpen(false) }
  const enter = (nextRole: Role) => { setRole(nextRole); const first = nextRole === 'merchant' ? merchantFeatures[0] : adminFeatures[0]; setSelected(first.label); window.history.pushState({}, '', `?feature=${encodeURIComponent(first.label)}`) }
  if (!role) return <Login onEnter={enter} />
  const feature = features.find(f => f.label === selected) ?? features[0]
  return <div className={`${dark ? 'dark ' : ''}app-shell`}><aside className={`sidebar ${menuOpen ? 'sidebar-open' : ''}`}><div className="flex h-16 items-center px-4"><Logo /></div><div className="px-3 pt-5"><div className="mb-3 px-2 text-[10px] uppercase tracking-widest text-muted-foreground">{role === 'merchant' ? 'Merchant workspace' : 'Evaluator workspace'}</div>{features.map(item => <button key={item.label} aria-label={item.label} className={`nav-item ${item.label === feature.label ? 'active' : ''}`} onClick={() => open(item)}><item.icon /><span>{item.label}</span></button>)}</div></aside><div className="main-shell"><header className="topbar"><button className="icon-button" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle navigation"><Menu /></button><div className="flex gap-2"><button className="icon-button" onClick={() => setDark(!dark)} aria-label="Toggle theme">{dark ? <Sun /> : <Moon />}</button><button className="profile-button" onClick={() => { setRole(null); window.history.pushState({}, '', '/') }}><span className="avatar">AS</span><LogOut /></button></div></header><main className="content"><div className="mb-7"><div className="eyebrow"><span className="size-1.5 rounded-full bg-lime" /> Tuesday · Bengaluru</div><h1 className="section-title">{feature.label}</h1><p className="mt-2 text-sm text-muted-foreground">{feature.description}</p></div><FeatureWorkspace feature={feature} role={role} /></main></div></div>
}

export default Page
